// FinSkor Service Worker v1.0
const CACHE_NAME = 'finskor-v1';

// Cache'lenecek dosyalar
const CACHE_FILES = [
  '/app.html',
  '/manifest.json',
  '/icon-192.png',
  '/icon-512.png',
  'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2',
  'https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js',
  'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js'
];

// Install — dosyaları cache'le
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => {
      // Kritik dosyaları cache'le, hata olsa devam et
      return Promise.allSettled(
        CACHE_FILES.map(url => cache.add(url).catch(() => {}))
      );
    }).then(() => self.skipWaiting())
  );
});

// Activate — eski cache'leri temizle
self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(
        keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k))
      )
    ).then(() => self.clients.claim())
  );
});

// Fetch — önce cache, sonra network (Network First for API calls)
self.addEventListener('fetch', event => {
  const url = new URL(event.request.url);

  // Supabase API istekleri her zaman network'ten git
  if (url.hostname.includes('supabase.co') ||
      url.hostname.includes('netlify') ||
      event.request.method !== 'GET') {
    return; // Tarayıcı varsayılanı
  }

  event.respondWith(
    caches.match(event.request).then(cached => {
      if (cached) return cached;
      return fetch(event.request).then(response => {
        // Başarılı yanıtları cache'le
        if (response && response.status === 200 && response.type === 'basic') {
          const clone = response.clone();
          caches.open(CACHE_NAME).then(cache => cache.put(event.request, clone));
        }
        return response;
      }).catch(() => {
        // Offline — app.html döndür
        if (event.request.destination === 'document') {
          return caches.match('/app.html');
        }
      });
    })
  );
});
